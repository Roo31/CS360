package com.example.projectcs360;
import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.graphics.Color;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.List;


public class HomeActivity extends AppCompatActivity {
    private static final int PERMISSION_SEND_SMS = 123; // Arbitrary integer for identifying the SMS permission request

    private CheckBox myCheckBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton button = findViewById(R.id.imageButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start SecondActivity
                Intent intent = new Intent(HomeActivity.this, InventoryActivity.class);
                startActivity(intent);
            }
        });
        // Setup CheckBox for SMS permission
        myCheckBox = findViewById(R.id.checkBox);
        SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        myCheckBox.setChecked(sharedPreferences.getBoolean("CheckBoxState", false));

        myCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("CheckBoxState", isChecked);
            editor.apply();

            if (isChecked) {
                // User checked the box
                Toast.makeText(HomeActivity.this, "Enabling SMS notifications...", Toast.LENGTH_SHORT).show();

                // Request SMS permission if not already granted
                if (ContextCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(HomeActivity.this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
                } else {
                    // Permission already granted, display enabled message
                    Toast.makeText(HomeActivity.this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
                }
            } else {
                // User unchecked the box, indicate that SMS notifications are disabled
                Toast.makeText(HomeActivity.this, "SMS notifications disabled.", Toast.LENGTH_SHORT).show();
            }
        });

        populateTableWithZeroAmountItems();

    }
    private void populateTableWithZeroAmountItems() {
        InventoryDatabase db = new InventoryDatabase(this);
        List<InventoryDatabase.Item> itemsWithZeroAmount = db.getItemsWithZeroAmount();

        TableLayout tableLayout = findViewById(R.id.tableLayout);

        // Clear previous table rows if needed
        tableLayout.removeAllViews();

        // Optionally, add a header row
        TableRow headerRow = new TableRow(this);
        headerRow.addView(createTextView("Name"));
        headerRow.addView(createTextView("Amount"));
        tableLayout.addView(headerRow);

        // Populate the table with items
        for (InventoryDatabase.Item item : itemsWithZeroAmount) {
            TableRow row = new TableRow(this);

            row.addView(createTextView(item.getName()));
            row.addView(createTextView(String.valueOf(item.getAmount())));


            tableLayout.addView(row);
        }
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(8, 8, 8, 8); // Adjust padding as needed
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        textView.setLayoutParams(params);
        textView.setTextColor(Color.WHITE);

        return textView;
    }
    public void sendSmsNotification(String itemName) { //set up for when the ability to send texts is enabled
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("8038649781", null, "Low inventory alert for: " + itemName, null, null);
            Toast.makeText(this, "SMS notification sent for " + itemName, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
    public interface InventoryUpdateListener {
        void onInventoryItemUpdated(long itemId, int newAmount);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                myCheckBox.setChecked(false);
            }
        }
    }

}