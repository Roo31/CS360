package com.example.projectcs360;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.text.InputType;
import android.widget.Button;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageButton;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;


public class InventoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.table_screen);
        ImageButton button = findViewById(R.id.imageButton2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start SecondActivity
                Intent intent = new Intent(InventoryActivity.this, HomeActivity.class);
                startActivity(intent);
    }
        });

        populateTable();
}
    public void onAddItemClicked(View view) {
        // Get the TextViews from the layout
        TextView nameTextView = findViewById(R.id.textView4);
        TextView amountTextView = findViewById(R.id.textView3);

        // Get the text values from the TextViews
        String title = nameTextView.getText().toString();
        String amountString = amountTextView.getText().toString();

        // Convert the amount from String to int
        int amount = 0;
        try {
            amount = Integer.parseInt(amountString);
        } catch (NumberFormatException e) {
            Log.e("InventoryActivity", "Error parsing amount to integer", e);
            // Optionally, show a toast message or handle the error as needed
            Toast.makeText(this, "Invalid amount entered", Toast.LENGTH_SHORT).show();
            return; // Exit the method early if the amount is invalid
        }

        // Create an instance of InventoryDatabase and call addItem on it
        InventoryDatabase inventoryDatabase = new InventoryDatabase(this);
        long result = inventoryDatabase.addItem(title, amount);

        // Check the result
        if (result != -1) {
            Log.d("InventoryDatabase", "Item has been added");
            populateTable(); // Refresh the table to show the new item
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
        } else {
            // Item insertion failed
            Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
        }
    }
   private void populateTable() {
       InventoryDatabase db = new InventoryDatabase(this);
       List<InventoryDatabase.Item> items = db.getAllItems(); // Get all items

       TableLayout tableLayout = findViewById(R.id.tableLayout2);
       tableLayout.removeAllViews(); // Clear previous content

       // Optionally, add a header row
       TableRow headerRow = new TableRow(this);
       headerRow.addView(createTextView("Name"));
       headerRow.addView(createTextView("Amount"));
       headerRow.addView(createTextView("Save")); // Column for save button
       headerRow.addView(createTextView("Delete"));
       tableLayout.addView(headerRow);

       // Populate table rows with items
       for (InventoryDatabase.Item item : items) {
           TableRow row = new TableRow(this);



           row.addView(createTextView(item.getName()));

           EditText editTextAmount = new EditText(this);
           editTextAmount.setTextColor(Color.WHITE);
           editTextAmount.setText(String.valueOf(item.getAmount()));
           editTextAmount.setInputType(InputType.TYPE_CLASS_NUMBER);
           editTextAmount.setGravity(Gravity.CENTER_HORIZONTAL);
           row.addView(editTextAmount);
           Button btnSave = new Button(this);

           btnSave.setText("Update");
           btnSave.setOnClickListener(v -> {
               int newAmount = Integer.parseInt(editTextAmount.getText().toString());
               updateItemAmount(item.getId(), newAmount); // Update the amount in the database
           });
           row.addView(btnSave);

           tableLayout.addView(row);
           // Add a Delete Button for each row
           Button deleteButton = new Button(this);
           deleteButton.setText("Delete");
           deleteButton.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
           deleteButton.setTextColor(Color.BLUE);
           deleteButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   // Call the delete item method
                   deleteItem(item.getId());
               }
           });
           row.addView(deleteButton);

       }
   }
    private void deleteItem(long itemId) {
        InventoryDatabase db = new InventoryDatabase(this);
        boolean success = db.deleteItem(itemId); // Ensure your InventoryDatabase has a deleteItem method
        if (success) {
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            populateTable(); // Refresh table to reflect deletion
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }
    private void updateItemAmount(long itemId, int newAmount) {
        InventoryDatabase db = new InventoryDatabase(this);
        db.updateItemAmount(itemId, newAmount); // Assume this method exists in InventoryDatabase
        populateTable(); // Refresh table to reflect changes
    }
    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(8, 8, 8, 8); // Adjust padding as needed
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        textView.setLayoutParams(params);
        textView.setTextColor(Color.WHITE);
        return textView;
    }
}