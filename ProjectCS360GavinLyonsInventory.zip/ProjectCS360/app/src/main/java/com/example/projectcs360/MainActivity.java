package com.example.projectcs360;

import androidx.appcompat.app.AppCompatActivity;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.content.Context;
import android.content.ContentValues;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }
    public void loginUser(View view) {
        EditText userField = findViewById(R.id.username);
        EditText passwordField = findViewById(R.id.textPassword);

        String name = userField.getText().toString();
        String password = passwordField.getText().toString();

        // Assuming LoginDatabase and User classes are correctly imported
        LoginDatabase db = new LoginDatabase(this);
        LoginDatabase.User user = db.getUserByName(name);
        // Your authentication logic here...
 //FIX THIS RIGHT HERE ADD THE VERIFICATION LOGIC
        if (user != null &&  user.getPassword().equals(password)) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            //setContentView(R.layout.activity_main);
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }
    public void createAccount(View view) {
        // Assuming you have EditText fields for username and password with respective IDs
        EditText usernameField = findViewById(R.id.username);
        EditText passwordField = findViewById(R.id.textPassword);

        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        Toast.makeText(this, "Button Pushed", Toast.LENGTH_SHORT).show();
        // Simple input validation
        if(username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Assuming LoginDatabase class has an addUser method that takes a User object
        LoginDatabase db = new LoginDatabase(this);

        // Create a new user (ensure your User class has an appropriate constructor)
        LoginDatabase.User newUser = new LoginDatabase.User(username, password);

        // Add user to the database
        db.addUser(newUser);

        // Show confirmation and clear input fields
        Toast.makeText(this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
        usernameField.setText("");
        passwordField.setText("");

    }

   /* public void goToTable(View view) {
        setContentView(R.layout.table_screen);
    }
    public void goToMain(View view) {
        setContentView(R.layout.activity_main);
    }*/
}
