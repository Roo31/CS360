package com.example.projectcs360;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.util.Log;
public class LoginDatabase extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "UserManager.db";

    // User table name
    private static final String TABLE_USER = "user";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_USER_PASSWORD = "user_password";

    // create table sql query
    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_PASSWORD + " TEXT" + ")";

    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;

    /**
     * Constructor
     *
     * @param context
     */
    public LoginDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        // Create a ContentValues object to hold the user data
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, "GLyons");
        values.put(COLUMN_USER_PASSWORD, "Hi");

        // Insert the user into the database
        db.insert(TABLE_USER, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop User Table if exist
        db.execSQL(DROP_USER_TABLE);

        // Create tables again
        onCreate(db);
    }

    /**
     * This method is to create user record
     *
     * @param user
     */
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // Inserting Row
        db.insert(TABLE_USER, null, values);
        db.close();
    }
    public static class User {

        private int id;
        private String name;
        private String password;

        /**
         * Constructor without id, for creating new users
         */
        public User(String name, String password) {
            this.name = name;
            this.password = password;
        }

        /**
         * Constructor with id, for fetching users from the database
         */
        public User(int id, String name, String password) {
            this.id = id;
            this.name = name;
            this.password = password;
        }

        // Getter and Setter methods

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
    public User getUserByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_NAME,
                COLUMN_USER_PASSWORD
        };

        String selection = COLUMN_USER_NAME + " = ?";
        String[] selectionArgs = {name};

        Cursor cursor = db.query(
                TABLE_USER, columns, selection, selectionArgs, null, null, null
        );

        User user = null;
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0); // Assuming COLUMN_USER_ID is the first column in your query
            String userName = cursor.getString(1); // Assuming COLUMN_USER_NAME is the second
            String password = cursor.getString(2); // Assuming COLUMN_USER_PASSWORD is the third

            user = new User(id, userName, password);
        } else {
            Log.d("LoginDatabase", "No user found with the name: " + name);
        }

        cursor.close();
        db.close();
        return user;
    }
}