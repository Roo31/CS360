package com.example.projectcs360;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;


public class InventoryDatabase extends SQLiteOpenHelper {
    private HomeActivity.InventoryUpdateListener updateListener;

    public class Item {
        private long id;       // Unique identifier for the item
        private String title;  // Title or name of the item
        private int amount;    // Quantity or amount of the item

        // Constructor
        public Item(long id, String title, int amount) {
            this.id = id;
            this.title = title;
            this.amount = amount;
        }

        // Getters
        public long getId() {
            return id;
        }

        public String getName() {
            return title;
        }

        public int getAmount() {
            return amount;
        }

        // Setters (if you need to modify the properties after object creation)
        public void setId(long id) {
            this.id = id;
        }

        public void setName(String title) {
            this.title = title;
        }

        public void setAmount(int amount) {
            this.amount = amount;
        }
    }
    private static final String TAG = "InventoryDatabase";
    private static final String DATABASE_NAME = "Inventory.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_INVENTORY = "Inventory";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_AMOUNT = "amount";
    public static final class InventoryTable {
        public static final String TABLE = "Inventory";
        public static final String COL_ID = "_id";
        // Other definitions...
    }
    private static final String CREATE_TABLE_INVENTORY = "CREATE TABLE " + TABLE_INVENTORY + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_TITLE + " TEXT," // Make sure this matches the column name you are using in ContentValues
            + COLUMN_AMOUNT + " INTEGER)";
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_INVENTORY);
        } catch (Exception e) {
            Log.e(TAG, "Error creating database table: " + CREATE_TABLE_INVENTORY, e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    /**
     * Adds an item to the inventory.
     *
     * @param title  The title of the item.
     * @param amount The amount of the item in inventory.
     * @return The row ID of the newly inserted row, or -1 if an error occurred.
     */
    public long addItem(String title, int amount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_AMOUNT, amount);

        long result = db.insert(TABLE_INVENTORY, null, values);

        if (result == -1) {
            Log.e(TAG, "Insertion failed for item: " + title);
        }

        db.close();
        return result;
    }
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(InventoryTable.TABLE, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            long id = cursor.getLong(0);
            String title = cursor.getString(1);
            int amount = cursor.getInt(2);
            items.add(new Item(id, title, amount));  // Assuming you have an Item class
        }
        cursor.close();
        db.close();
        return items;
    }
    public boolean deleteItem(long itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Define the selection criteria (where clause)
        String selection = InventoryTable.COL_ID + " = ?";
        // Specify the corresponding selection argument
        String[] selectionArgs = { String.valueOf(itemId) };
        // Perform the delete operation
        int deletedRows = db.delete(InventoryTable.TABLE, selection, selectionArgs);
        db.close();
        // If deletedRows is greater than 0, the delete operation was successful
        return deletedRows > 0;
    }
    public List<Item> getItemsWithZeroAmount() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Define a selection criteria where the amount is 0
        String selection = COLUMN_AMOUNT + "=?";
        String[] selectionArgs = {"0"};

        Cursor cursor = db.query(TABLE_INVENTORY, null, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String title = cursor.getString(1);
                int amount = cursor.getInt(2);

                items.add(new Item(id, title, amount));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return items;
    }
    public void setInventoryUpdateListener(HomeActivity.InventoryUpdateListener listener) {
        this.updateListener = listener;
    }
    public int updateItemAmount(long itemId, int newAmount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_AMOUNT, newAmount);

        // Update the item in the database
        int rowsAffected = db.update(TABLE_INVENTORY, values, COLUMN_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        if (newAmount == 0 && updateListener != null) {
            updateListener.onInventoryItemUpdated(itemId, newAmount);
        }
        return rowsAffected;
    }
}
